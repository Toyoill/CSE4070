#ifndef TESTS_FILESYS_BASE_SYN_WRITE_H
#define TESTS_FILESYS_BASE_SYN_WRITE_H

#define CHILD_CNT 10
#define CHUNK_SIZE 512
#define BUF_SIZE (CHILD_CNT * CHUNK_SIZE)
static const char file_name[] = "stuff";

#endif /* tests/filesys/base/syn-write.h */
